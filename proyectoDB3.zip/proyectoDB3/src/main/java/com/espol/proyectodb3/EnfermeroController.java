package com.espol.proyectodb3;

public class EnfermeroController {
}
