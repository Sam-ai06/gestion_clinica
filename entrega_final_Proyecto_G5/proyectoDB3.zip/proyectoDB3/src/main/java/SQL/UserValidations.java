package SQL;

import javafx.scene.control.Label;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserValidations {

    //validación de usuario
    public static boolean validateUser(String username, String plainPassword, String role) {
        String sql = "SELECT contraseña FROM personas WHERE usuario = ? AND rol = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Buscar el hash almacenado para ese usuario
            statement.setString(1, username);
            statement.setString(2, role);

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    String storedHash = result.getString("contraseña");
                    // Verificar si el password plano coincide con el hash almacenado
                    return BCrypt.checkpw(plainPassword, storedHash);
                }
                return false; // Usuario no encontrado
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ NUEVO MÉTODO: Obtener cédula por usuario y rol
    public static String obtenerCedulaPorUsuario(String usuario, String rol) {
        String cedula = null;
        String sql = "SELECT cedula FROM personas WHERE usuario = ? AND rol = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, rol);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                cedula = rs.getString("cedula");
                System.out.println("Cédula encontrada para usuario '" + usuario + "': " + cedula);
            } else {
                System.err.println("No se encontró cédula para usuario: " + usuario + " con rol: " + rol);
            }

        } catch (SQLException e) {
            System.err.println("Error obteniendo cédula por usuario: " + e.getMessage());
            e.printStackTrace();
        }

        return cedula;
    }

    public static void guardarRegistro(String cedula, String nombre, String apellido, int edad, String correo,
                                       String telefono, String direccion1, String usuario, String contrasena, String rol) {

        String hashedPassword = BCrypt.hashpw(contrasena, BCrypt.gensalt());
        Connection connection = null;

        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false); // Iniciar transacción

            // 1. Insertar en tabla personas
            String sqlPersonas = "INSERT INTO personas (cedula, nombre, apellido, edad, correo, telefono, " +
                    "direccion1, usuario, contraseña, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement stmtPersonas = connection.prepareStatement(sqlPersonas)) {
                stmtPersonas.setString(1, cedula);
                stmtPersonas.setString(2, nombre);
                stmtPersonas.setString(3, apellido);
                stmtPersonas.setInt(4, edad);
                stmtPersonas.setString(5, correo);
                stmtPersonas.setString(6, telefono);
                stmtPersonas.setString(7, direccion1);
                stmtPersonas.setString(8, usuario);
                stmtPersonas.setString(9, hashedPassword);
                stmtPersonas.setString(10, rol);
                stmtPersonas.executeUpdate();
            }

            switch (rol.toLowerCase()) {
                case "admin":
                    guardarAdmin(connection, cedula);
                    break;
                case "staff":
                    guardarDoctor(connection, cedula, "General");
                    break;
                case "enfermero":
                    guardarEnfermero(connection, cedula, "General");
                    break;
                case "cliente":
                    guardarCliente(connection, cedula);
                    break;
                default:
                    throw new SQLException("Rol no válido: " + rol);
            }

            connection.commit();
            System.out.println("Registro guardado exitosamente.");

        } catch (SQLException e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.out.println("Error al guardar el registro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    //guardar en admins
    public static void guardarAdmin(Connection connection, String cedula) throws SQLException{
        String sql = "INSERT INTO administradores (cedula) VALUES (?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cedula);
            statement.executeUpdate();
            System.out.println("Admin Guardado Exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar el admin: " + e.getMessage());
            throw e;
        }

    }

    //guardar en doctores
    public static void guardarDoctor(Connection connection, String cedula, String especialidad) throws SQLException{
        String sql = "INSERT INTO doctores (cedula, especialidad) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cedula);
            statement.setString(2, especialidad);
            statement.executeUpdate();
            System.out.println("Doctor Guardado Exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar el doctor: " + e.getMessage());
            throw e;
        }
    }

    //guardar en enfermeros
    public static void guardarEnfermero(Connection connection, String cedula, String area) throws SQLException{
        String sql = "INSERT INTO enfermeros (cedula, area) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cedula);
            statement.setString(2, area);
            statement.executeUpdate();
            System.out.println("Enfermero Guardado Exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar el enfermero: " + e.getMessage());
            throw e;
        }
    }

    //guardar en clientes
    public static void guardarCliente(Connection connection, String cedula) throws SQLException{
        String sql = "INSERT INTO clientes (cedula, puede_agendar_citas) VALUES (?, TRUE)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cedula);
            statement.executeUpdate();
            System.out.println("Cliente Guardado Exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al guardar el cliente: " + e.getMessage());
            throw e;
        }
    }

    //validar usuario
    public boolean validateUser(String user){
        String sql = "SELECT * FROM personas WHERE usuario = ?";
        try{
            Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, user);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()){
                return true;
            } else {
                return false;
            }
        } catch (SQLException e){
            e.printStackTrace();
            return false;
        }

    }

    public void changePassword(String user, String newPassword, Label label) {
        String sql = "UPDATE personas SET contraseña = ? WHERE usuario = ?";

        String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, hashedPassword);
            statement.setString(2, user);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                label.setStyle("-fx-text-fill: green;");
                label.setText("Contraseña actualizada exitosamente.");
            } else {
                label.setText("Error al actualizar la contraseña.");
            }

        } catch (SQLException e) {
            System.out.println("error en la clase userValidations");
            e.printStackTrace();
        }
    }

    //eliminar un usuario
    public void eliminarUsuario(String username, Label label){
        String sql = "DELETE FROM personas WHERE usuario = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                label.setStyle("-fx-text-fill: green;");
                label.setText("Usuario eliminado exitosamente.");
            } else {
                label.setText("Error al eliminar el usuario.");
            }
        } catch (SQLException e) {
            System.out.println("error en la clase userValidations");
            e.printStackTrace();
        }
    }
}